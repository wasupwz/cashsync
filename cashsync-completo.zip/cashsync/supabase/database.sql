-- =====================================================
-- CASHSYNC — SUPABASE DATABASE SETUP
-- Cole este SQL no Supabase > SQL Editor > New Query
-- =====================================================

-- 1. TABELA DE USUÁRIOS (perfis)
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  nome TEXT NOT NULL,
  sobrenome TEXT,
  email TEXT UNIQUE NOT NULL,
  tipo_conta TEXT DEFAULT 'pessoal' CHECK (tipo_conta IN ('pessoal', 'empresa')),
  nome_empresa TEXT,
  cnpj TEXT,
  segmento TEXT,
  plano TEXT DEFAULT 'starter' CHECK (plano IN ('starter', 'pro', 'enterprise', 'vitalicio')),
  status_assinatura TEXT DEFAULT 'trial' CHECK (status_assinatura IN ('trial', 'ativo', 'cancelado', 'expirado', 'vitalicio')),
  trial_expira_em TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '14 days'),
  assinatura_id TEXT, -- ID da assinatura na Cakto
  proximo_pagamento TIMESTAMPTZ,
  criado_em TIMESTAMPTZ DEFAULT NOW(),
  atualizado_em TIMESTAMPTZ DEFAULT NOW()
);

-- 2. TABELA DE PAGAMENTOS (webhook da Cakto)
CREATE TABLE IF NOT EXISTS pagamentos (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id),
  email_comprador TEXT NOT NULL,
  plano TEXT NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('aprovado', 'cancelado', 'reembolsado', 'pendente')),
  cakto_order_id TEXT UNIQUE,
  cakto_subscription_id TEXT,
  metodo_pagamento TEXT,
  proximo_vencimento TIMESTAMPTZ,
  criado_em TIMESTAMPTZ DEFAULT NOW()
);

-- 3. TABELA DE LANÇAMENTOS FINANCEIROS
CREATE TABLE IF NOT EXISTS lancamentos (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('receita', 'despesa')),
  descricao TEXT NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  categoria TEXT,
  data_lancamento DATE DEFAULT CURRENT_DATE,
  data_vencimento DATE,
  status TEXT DEFAULT 'confirmado' CHECK (status IN ('confirmado', 'pendente', 'cancelado')),
  recorrente BOOLEAN DEFAULT FALSE,
  intervalo_recorrencia TEXT CHECK (intervalo_recorrencia IN ('mensal', 'semanal', 'anual')),
  criado_em TIMESTAMPTZ DEFAULT NOW()
);

-- 4. TABELA DE CONTAS A PAGAR/RECEBER
CREATE TABLE IF NOT EXISTS contas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('pagar', 'receber')),
  descricao TEXT NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  data_vencimento DATE NOT NULL,
  status TEXT DEFAULT 'pendente' CHECK (status IN ('pendente', 'pago', 'vencido', 'cancelado')),
  categoria TEXT,
  observacoes TEXT,
  criado_em TIMESTAMPTZ DEFAULT NOW()
);

-- 5. TABELA DE COBRANÇAS MENSAIS (controle de recorrência)
CREATE TABLE IF NOT EXISTS cobrancas_mensais (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  plano TEXT NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  mes_referencia DATE NOT NULL, -- primeiro dia do mês
  status TEXT DEFAULT 'pendente' CHECK (status IN ('pendente', 'pago', 'falhou', 'cancelado')),
  cakto_order_id TEXT,
  tentativas INT DEFAULT 0,
  proximo_tentativa TIMESTAMPTZ,
  criado_em TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- ROW LEVEL SECURITY (cada usuário vê só os próprios dados)
-- =====================================================
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE lancamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE contas ENABLE ROW LEVEL SECURITY;
ALTER TABLE cobrancas_mensais ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuário vê próprio perfil" ON profiles FOR ALL USING (auth.uid() = id);
CREATE POLICY "Usuário vê próprios lançamentos" ON lancamentos FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Usuário vê próprias contas" ON contas FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Usuário vê próprias cobranças" ON cobrancas_mensais FOR SELECT USING (auth.uid() = user_id);

-- Pagamentos só admin pode ver (via service_role)
ALTER TABLE pagamentos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Somente service_role acessa pagamentos" ON pagamentos USING (FALSE);

-- =====================================================
-- TRIGGER: atualiza perfil quando plano muda
-- =====================================================
CREATE OR REPLACE FUNCTION atualizar_perfil_pagamento()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'aprovado' THEN
    UPDATE profiles
    SET 
      plano = NEW.plano,
      status_assinatura = 'ativo',
      assinatura_id = NEW.cakto_subscription_id,
      proximo_pagamento = NEW.proximo_vencimento,
      atualizado_em = NOW()
    WHERE email = NEW.email_comprador;
  ELSIF NEW.status = 'cancelado' THEN
    UPDATE profiles
    SET
      status_assinatura = 'cancelado',
      atualizado_em = NOW()
    WHERE email = NEW.email_comprador;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_pagamento_insert
  AFTER INSERT ON pagamentos
  FOR EACH ROW EXECUTE FUNCTION atualizar_perfil_pagamento();

-- =====================================================
-- TRIGGER: cria perfil automaticamente no cadastro
-- =====================================================
CREATE OR REPLACE FUNCTION criar_perfil_novo_usuario()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, nome, email)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'nome', 'Usuário'),
    NEW.email
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION criar_perfil_novo_usuario();

-- =====================================================
-- COBRANÇAS MENSAIS: gera cobranças automaticamente
-- Rode via pg_cron (Supabase > Extensions > pg_cron)
-- =====================================================

-- Habilitar extensão pg_cron (rode separado):
-- CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Agendar job mensal (dia 1 de cada mês às 08:00):
-- SELECT cron.schedule('cobrar-mensalmente', '0 8 1 * *', $$
--   INSERT INTO cobrancas_mensais (user_id, plano, valor, mes_referencia)
--   SELECT 
--     id,
--     plano,
--     CASE plano WHEN 'pro' THEN 97.00 WHEN 'enterprise' THEN 297.00 END,
--     date_trunc('month', NOW())
--   FROM profiles
--   WHERE status_assinatura = 'ativo'
--   AND plano IN ('pro', 'enterprise')
--   AND (proximo_pagamento IS NULL OR proximo_pagamento <= NOW());
-- $$);

-- =====================================================
-- VERIFICAR CONTAS VENCIDAS (rode diariamente)
-- =====================================================
-- SELECT cron.schedule('verificar-vencimentos', '0 9 * * *', $$
--   UPDATE contas 
--   SET status = 'vencido' 
--   WHERE status = 'pendente' 
--   AND data_vencimento < CURRENT_DATE;
-- $$);
