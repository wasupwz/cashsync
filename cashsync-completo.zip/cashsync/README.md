# CashSync — Guia de Deploy Completo

## CHECKLIST DE 6 PASSOS PARA IR AO AR

---

### ✅ PASSO 1 — Domínio (registro.br)
1. Acesse https://registro.br
2. Busque por: `cashsync.com.br`
3. Se disponível, clique em Registrar
4. Crie sua conta com CPF
5. Pague via Pix (R$40/ano)
6. Domínio ativo em até 24h

---

### ✅ PASSO 2 — Supabase (banco de dados)
1. Acesse https://supabase.com
2. Clique em "Start your project" → entre com GitHub
3. Crie conta GitHub em https://github.com se não tiver (gratuito)
4. No Supabase: "New Project" → nome: CashSync → região: South America (São Paulo)
5. Aguarde ~2 minutos criando
6. Vá em Settings → API
7. Copie: **URL do projeto** e **anon/public key** e **service_role key**
8. Abra o arquivo `supabase/database.sql` deste projeto
9. No Supabase: clique em "SQL Editor" → "New Query"
10. Cole TODO o conteúdo do database.sql e clique em "RUN"
11. ✅ Banco configurado!

---

### ✅ PASSO 3 — Vercel (hospedagem gratuita)
1. Acesse https://vercel.com
2. Clique em "Sign Up" → entre com sua conta GitHub
3. Clique em "Add New Project"
4. Clique em "Upload" e suba a pasta `cashsync` inteira (ou conecte ao GitHub)
5. Em "Environment Variables", adicione:
   - `SUPABASE_URL` = sua URL do Supabase
   - `SUPABASE_SERVICE_ROLE_KEY` = sua service_role key
6. Clique em Deploy
7. Vercel gera uma URL tipo: https://cashsync-xyz.vercel.app

---

### ✅ PASSO 4 — Conectar domínio à Vercel
1. No painel Vercel → seu projeto → "Settings" → "Domains"
2. Digite: `cashsync.com.br`
3. Vercel te dará um DNS Record (tipo CNAME ou A)
4. Acesse registro.br → seu domínio → "Configurar DNS"
5. Adicione o registro que a Vercel pediu
6. Aguarde até 24h para propagar
7. ✅ Seu site estará em cashsync.com.br!

---

### ✅ PASSO 5 — Webhook da Cakto
1. Acesse sua conta Cakto
2. Vá em: Configurações → Webhooks → Adicionar Webhook
3. URL: `https://cashsync.com.br/api/webhook-cakto`
4. Eventos para selecionar:
   - ✅ purchase.approved (compra aprovada)
   - ✅ subscription.renewed (renovação mensal)
   - ✅ subscription.cancelled (cancelamento)
   - ✅ subscription.payment_failed (falha no pagamento)
5. Salve e teste com "Enviar teste"
6. ✅ Aprovação automática funcionando!

---

### ✅ PASSO 6 — Testar tudo
1. Acesse cashsync.com.br
2. Crie uma conta de teste
3. Faça um pagamento teste na Cakto
4. Verifique no Supabase > Table Editor > profiles se o plano foi atualizado
5. ✅ TUDO FUNCIONANDO!

---

## VARIÁVEIS DE AMBIENTE (.env.local para desenvolvimento)

```
SUPABASE_URL=https://XXXX.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGc...
```

---

## ARQUIVOS DO PROJETO

```
cashsync/
├── index.html          ← Site completo (landing + cadastro + dashboard)
├── vercel.json         ← Configuração de deploy
├── api/
│   └── webhook-cakto.js ← Aprovação automática de pagamentos
└── supabase/
    └── database.sql    ← Estrutura do banco de dados
```

---

## CUPOM VITALÍCIO

O cupom **PEDRO100** existe no código do site (`index.html`, linha com `VALID_COUPON`).
Ele não aparece em nenhum lugar público — só funciona se o usuário digitar exatamente.
Para mudar o cupom futuramente, edite a variável `VALID_COUPON` no index.html.

---

## SUPORTE

Email: editaispedro@gmail.com
Instagram: @CashSyn
