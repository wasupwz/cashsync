// =====================================================
// CASHSYNC — WEBHOOK DA CAKTO
// Este arquivo fica em: /api/webhook-cakto.js
// Hospede na Vercel como serverless function
// =====================================================
// 
// CONFIGURAÇÃO NA CAKTO:
// 1. Acesse sua conta Cakto > Configurações > Webhooks
// 2. URL do webhook: https://SEU-DOMINIO.vercel.app/api/webhook-cakto
// 3. Selecione os eventos: purchase.approved, subscription.cancelled, subscription.renewed
// =====================================================

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY // service_role, não anon!
);

// Mapeia produto Cakto → plano CashSync
const PLANO_MAP = {
  'kyeue5e_806442': 'pro',      // R$97/mês
  'yv25wqf_806445': 'enterprise' // R$297/mês
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const payload = req.body;
    const evento = payload.event || payload.type;
    const dados = payload.data || payload;

    console.log('[CashSync Webhook] Evento recebido:', evento);
    console.log('[CashSync Webhook] Payload:', JSON.stringify(dados, null, 2));

    // ==========================================
    // EVENTO: Compra aprovada
    // ==========================================
    if (evento === 'purchase.approved' || evento === 'order.paid') {
      const emailComprador = dados.customer?.email || dados.email;
      const produtoId = dados.product?.id || dados.product_id;
      const plano = PLANO_MAP[produtoId] || 'pro';
      const valor = dados.amount || dados.total || 0;
      const orderId = dados.order_id || dados.id;
      const subscriptionId = dados.subscription_id || dados.recurring_id;
      const proximoVencimento = dados.next_billing_date 
        ? new Date(dados.next_billing_date) 
        : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // +30 dias

      // Registra o pagamento
      const { error: pgError } = await supabase
        .from('pagamentos')
        .upsert({
          email_comprador: emailComprador,
          plano: plano,
          valor: valor / 100, // Cakto envia em centavos
          status: 'aprovado',
          cakto_order_id: orderId,
          cakto_subscription_id: subscriptionId,
          metodo_pagamento: dados.payment_method || 'cartao',
          proximo_vencimento: proximoVencimento.toISOString()
        }, { onConflict: 'cakto_order_id' });

      if (pgError) console.error('Erro ao salvar pagamento:', pgError);

      // Atualiza o perfil do usuário (o trigger no Supabase cuida disso automaticamente)
      // Mas fazemos manual também como fallback:
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          plano: plano,
          status_assinatura: 'ativo',
          assinatura_id: subscriptionId,
          proximo_pagamento: proximoVencimento.toISOString(),
          atualizado_em: new Date().toISOString()
        })
        .eq('email', emailComprador);

      if (profileError) console.error('Erro ao atualizar perfil:', profileError);

      console.log(`✅ Plano ${plano} ativado para: ${emailComprador}`);
      return res.status(200).json({ success: true, message: 'Plano ativado' });
    }

    // ==========================================
    // EVENTO: Assinatura renovada (cobrança mensal)
    // ==========================================
    if (evento === 'subscription.renewed' || evento === 'subscription.charged') {
      const emailComprador = dados.customer?.email || dados.email;
      const produtoId = dados.product?.id || dados.product_id;
      const plano = PLANO_MAP[produtoId] || 'pro';
      const orderId = dados.order_id || dados.id;
      const subscriptionId = dados.subscription_id;
      const proximoVencimento = dados.next_billing_date
        ? new Date(dados.next_billing_date)
        : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

      // Registra a renovação
      await supabase.from('pagamentos').insert({
        email_comprador: emailComprador,
        plano: plano,
        valor: dados.amount / 100,
        status: 'aprovado',
        cakto_order_id: orderId,
        cakto_subscription_id: subscriptionId,
        metodo_pagamento: 'cartao_recorrente',
        proximo_vencimento: proximoVencimento.toISOString()
      });

      // Mantém conta ativa
      await supabase
        .from('profiles')
        .update({
          status_assinatura: 'ativo',
          proximo_pagamento: proximoVencimento.toISOString(),
          atualizado_em: new Date().toISOString()
        })
        .eq('email', emailComprador);

      // Registra cobrança mensal
      await supabase.from('cobrancas_mensais').insert({
        plano: plano,
        valor: dados.amount / 100,
        mes_referencia: new Date().toISOString().slice(0, 7) + '-01',
        status: 'pago',
        cakto_order_id: orderId
      });

      console.log(`🔄 Renovação processada para: ${emailComprador}`);
      return res.status(200).json({ success: true, message: 'Renovação processada' });
    }

    // ==========================================
    // EVENTO: Assinatura cancelada
    // ==========================================
    if (evento === 'subscription.cancelled' || evento === 'subscription.canceled') {
      const emailComprador = dados.customer?.email || dados.email;

      await supabase
        .from('profiles')
        .update({
          status_assinatura: 'cancelado',
          atualizado_em: new Date().toISOString()
        })
        .eq('email', emailComprador);

      await supabase.from('pagamentos').insert({
        email_comprador: emailComprador,
        plano: 'cancelado',
        valor: 0,
        status: 'cancelado',
        cakto_order_id: dados.order_id || dados.id
      });

      console.log(`❌ Assinatura cancelada para: ${emailComprador}`);
      return res.status(200).json({ success: true, message: 'Cancelamento processado' });
    }

    // ==========================================
    // EVENTO: Pagamento com falha
    // ==========================================
    if (evento === 'subscription.payment_failed') {
      const emailComprador = dados.customer?.email || dados.email;

      await supabase
        .from('profiles')
        .update({
          status_assinatura: 'expirado',
          atualizado_em: new Date().toISOString()
        })
        .eq('email', emailComprador);

      console.log(`⚠️ Pagamento falhou para: ${emailComprador}`);
      return res.status(200).json({ success: true, message: 'Falha processada' });
    }

    // Evento não mapeado — retorna 200 mesmo assim (evita retry da Cakto)
    return res.status(200).json({ success: true, message: 'Evento ignorado: ' + evento });

  } catch (error) {
    console.error('[CashSync Webhook] ERRO:', error);
    return res.status(500).json({ error: 'Erro interno', details: error.message });
  }
}
